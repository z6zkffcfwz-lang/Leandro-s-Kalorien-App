# Leandro’s Kalorien App – iOS-Starterprojekt

Dies ist der SwiftUI-Quellcode für eine native iPhone-App im Dark Mode.

## Enthalten
- Tages-Dashboard mit editierbarem Kalorienziel
- Mahlzeiten und Nährwerte hinzufügen/löschen
- Makroübersicht: Eiweiß, Kohlenhydrate und Fett
- Gewichtseinträge
- Lokale Speicherung auf dem Gerät via `UserDefaults`
- Bereiche für Statistik, Fotoanalyse und Barcode-Funktion

## Noch nicht enthalten
Fotoerkennung, Kamera-Barcodescanner, Online-Lebensmitteldatenbank und echte Wochenverlaufsdiagramme sind ausdrücklich noch nicht verbunden. Der Prototyp behauptet daher nicht, Barcodes oder Fotos bereits automatisch auswerten zu können.

## In Xcode starten
1. Auf einem Mac die aktuelle Xcode-Version aus dem Mac App Store installieren.
2. Xcode öffnen → **Create a new Xcode project** → **iOS → App**.
3. Product Name: `LeandrosKalorienApp`; Interface: **SwiftUI**; Language: **Swift**.
4. Die von Xcode erzeugte `LeandrosKalorienAppApp.swift` durch die gleichnamige Datei aus diesem Paket ersetzen. Den restlichen Inhalt in dieselbe Datei übernehmen bzw. als einzelne Swift-Datei hinzufügen.
5. Unter **Signing & Capabilities** ein eigenes Team auswählen und eine eindeutige Bundle Identifier eintragen.
6. Auf einem angeschlossenen iPhone oder im iOS Simulator ausführen.

## Voraussetzungen
- Ein Mac mit Xcode für den Build und die Installation einer nativen iOS-App.
- Für die Verteilung über TestFlight/App Store wird ein Apple Developer Account benötigt.
- Dieses Paket ist Quellcode, keine bereits signierte oder installierbare IPA-Datei.

## Datenschutz
Die erfassten Einträge werden in diesem Starter lokal auf dem Gerät gespeichert. Es gibt keine Cloud-Synchronisierung. Für eine spätere Veröffentlichung sollten Datenschutz, Datensicherung, Löschfunktionen und Gesundheits-/Ernährungshinweise geprüft werden.
