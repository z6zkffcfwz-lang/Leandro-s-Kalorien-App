# Leandro's Kalorien App

SwiftUI starter project targeting iOS 17+.

Includes a dark calorie dashboard, manually entered meals and macros, a seven-day calorie overview, and local weight tracking. Photo recognition and barcode scanning are not implemented yet.

Codemagic builds an unsigned app for verification. Installing on an iPhone requires signing and a supported distribution method.
