import SwiftUI

@main
struct LeandrosKalorienApp: App {
    var body: some Scene {
        WindowGroup { ContentView() }
    }
}

struct FoodEntry: Identifiable, Codable {
    var id = UUID()
    var name: String
    var calories: Int
    var protein: Double
    var carbs: Double
    var fat: Double
    var date: Date = .now
}
struct WeightEntry: Identifiable, Codable {
    var id = UUID()
    var weight: Double
    var date: Date
}

struct ContentView: View {
    @AppStorage("dailyGoal") private var dailyGoal = 2200
    @AppStorage("foodEntriesData") private var foodData = Data()
    @AppStorage("weightEntriesData") private var weightData = Data()
    @State private var entries: [FoodEntry] = []
    @State private var addFood = false
    @State private var weightText = ""
    @State private var tab = 0

    private var today: [FoodEntry] { entries.filter { Calendar.current.isDateInToday($0.date) } }
    private var calories: Int { today.reduce(0) { $0 + $1.calories } }
    private var protein: Double { today.reduce(0) { $0 + $1.protein } }
    private var carbs: Double { today.reduce(0) { $0 + $1.carbs } }
    private var fat: Double { today.reduce(0) { $0 + $1.fat } }

    var body: some View {
        TabView(selection: $tab) {
            home.tabItem { Label("Heute", systemImage: "sun.max.fill") }.tag(0)
            stats.tabItem { Label("Statistik", systemImage: "chart.bar.fill") }.tag(1)
            weights.tabItem { Label("Gewicht", systemImage: "scalemass.fill") }.tag(2)
        }
        .tint(.mint).preferredColorScheme(.dark)
        .onAppear { entries = (try? JSONDecoder().decode([FoodEntry].self, from: foodData)) ?? [] }
    }

    private var home: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    VStack(alignment: .leading, spacing: 5) {
                        Text("LEANDRO’S").font(.caption.bold()).tracking(3).foregroundStyle(.mint)
                        Text("Kalorien").font(.largeTitle.bold())
                        Text(Date.now.formatted(date: .complete, time: .omitted)).foregroundStyle(.secondary)
                    }
                    VStack(alignment: .leading, spacing: 14) {
                        HStack(alignment: .firstTextBaseline) {
                            Text("\(calories)").font(.system(size: 42, weight: .bold, design: .rounded))
                            Text("kcal gegessen").foregroundStyle(.secondary)
                            Spacer()
                        }
                        ProgressView(value: min(Double(calories), Double(max(dailyGoal, 1))), total: Double(max(dailyGoal, 1))).tint(.mint)
                        Text("\(max(0, dailyGoal-calories)) kcal übrig").font(.subheadline.bold()).foregroundStyle(.mint)
                        HStack {
                            macro("Protein", protein, .cyan); Spacer()
                            macro("Kohlenhydrate", carbs, .orange); Spacer()
                            macro("Fett", fat, .pink)
                        }
                    }.padding(18).background(Color(.secondarySystemBackground), in: RoundedRectangle(cornerRadius: 22))
                    HStack {
                        Text("Mahlzeiten").font(.title2.bold()); Spacer()
                        Button { addFood = true } label: { Label("Hinzufügen", systemImage: "plus") }
                            .buttonStyle(.borderedProminent).tint(.mint)
                    }
                    if today.isEmpty {
                        ContentUnavailableView("Noch keine Mahlzeiten", systemImage: "fork.knife", description: Text("Füge deine erste Mahlzeit hinzu."))
                    } else {
                        ForEach(today.reversed()) { e in
                            HStack {
                                Image(systemName: "fork.knife.circle.fill").font(.title).foregroundStyle(.mint)
                                VStack(alignment: .leading) {
                                    Text(e.name).font(.headline)
                                    Text("P \(Int(e.protein)) g · KH \(Int(e.carbs)) g · F \(Int(e.fat)) g").font(.caption).foregroundStyle(.secondary)
                                }
                                Spacer(); Text("\(e.calories) kcal").bold()
                            }.padding(14).background(Color(.secondarySystemBackground), in: RoundedRectangle(cornerRadius: 16))
                            .contextMenu { Button("Löschen", role: .destructive) { entries.removeAll { $0.id == e.id }; save() } }
                        }
                    }
                    Text("Mahlzeit gedrückt halten, um sie zu löschen.").font(.caption).foregroundStyle(.secondary)
                }.padding()
            }.background(Color.black.ignoresSafeArea()).toolbar(.hidden, for: .navigationBar)
            .sheet(isPresented: $addFood) { AddFoodView { entries.append($0); save() }.presentationDetents([.medium, .large]) }
        }
    }
    private func macro(_ title: String, _ amount: Double, _ color: Color) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            Text("\(Int(amount)) g").font(.headline)
            Text(title).font(.caption).foregroundStyle(.secondary)
        }.foregroundStyle(color)
    }
    private var stats: some View {
        NavigationStack {
            List {
                Section("Heute") {
                    LabeledContent("Kalorien", value: "\(calories) kcal")
                    LabeledContent("Protein", value: "\(Int(protein)) g")
                    LabeledContent("Kohlenhydrate", value: "\(Int(carbs)) g")
                    LabeledContent("Fett", value: "\(Int(fat)) g")
                }
                Section("Letzte 7 Tage") {
                    ForEach((0..<7).reversed(), id: \.self) { offset in
                        let day = Calendar.current.date(byAdding: .day, value: -offset, to: .now)!
                        let items = entries.filter { Calendar.current.isDate($0.date, inSameDayAs: day) }
                        HStack { Text(day.formatted(.dateTime.weekday(.abbreviated).day())); Spacer(); Text("\(items.reduce(0) { $0 + $1.calories }) kcal").foregroundStyle(.mint).bold() }
                    }
                }
            }.navigationTitle("Statistik")
        }
    }
    private var weights: some View {
        NavigationStack {
            VStack(spacing: 14) {
                Image(systemName: "scalemass.fill").font(.system(size: 40)).foregroundStyle(.mint)
                Text("Gewicht verfolgen").font(.title.bold())
                TextField("Gewicht in kg", text: $weightText).keyboardType(.decimalPad).textFieldStyle(.roundedBorder).padding(.horizontal)
                Button("Gewicht speichern") {
                    guard let w = Double(weightText.replacingOccurrences(of: ",", with: ".")), w > 0 else { return }
                    var values = (try? JSONDecoder().decode([WeightEntry].self, from: weightData)) ?? []
                    values.append(WeightEntry(weight: w, date: .now))
                    weightData = (try? JSONEncoder().encode(values)) ?? Data(); weightText = ""
                }.buttonStyle(.borderedProminent).tint(.mint)
                List {
                    let values = (try? JSONDecoder().decode([WeightEntry].self, from: weightData)) ?? []
                    ForEach(values.reversed()) { item in
                        HStack { Text(item.date.formatted(date: .abbreviated, time: .omitted)); Spacer(); Text(String(format: "%.1f kg", item.weight)).bold() }
                    }
                }
            }.padding(.top).navigationTitle("Gewicht")
        }
    }
    private func save() { foodData = (try? JSONEncoder().encode(entries)) ?? Data() }
}

struct AddFoodView: View {
    @Environment(\.dismiss) private var dismiss
    @State private var name = ""
    @State private var calories = ""
    @State private var protein = ""
    @State private var carbs = ""
    @State private var fat = ""
    var onSave: (FoodEntry) -> Void
    var body: some View {
        NavigationStack {
            Form {
                Section("Mahlzeit") {
                    TextField("Name der Mahlzeit", text: $name)
                    TextField("Kalorien (kcal)", text: $calories).keyboardType(.numberPad)
                }
                Section("Makronährstoffe (g)") {
                    TextField("Protein", text: $protein).keyboardType(.decimalPad)
                    TextField("Kohlenhydrate", text: $carbs).keyboardType(.decimalPad)
                    TextField("Fett", text: $fat).keyboardType(.decimalPad)
                }
                Section { Text("Fotoerkennung und Barcode-Scanner sind noch nicht enthalten.").font(.caption).foregroundStyle(.secondary) }
            }.navigationTitle("Mahlzeit hinzufügen")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Abbrechen") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Speichern") {
                        onSave(FoodEntry(name: name.isEmpty ? "Mahlzeit" : name, calories: Int(calories) ?? 0,
                            protein: Double(protein.replacingOccurrences(of: ",", with: ".")) ?? 0,
                            carbs: Double(carbs.replacingOccurrences(of: ",", with: ".")) ?? 0,
                            fat: Double(fat.replacingOccurrences(of: ",", with: ".")) ?? 0))
                        dismiss()
                    }.disabled(calories.isEmpty)
                }
            }
        }.preferredColorScheme(.dark)
    }
}
